package com.filetool.util;

public class Consts {
public static final String INPUTFILE="case1.txt";
}

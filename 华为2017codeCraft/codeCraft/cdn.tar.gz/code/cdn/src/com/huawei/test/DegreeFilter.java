package com.huawei.test;

public class DegreeFilter {
public boolean Filter(int s){
	return true;
}
}

package com.huawei.test;

public class test {
public static void main(String[]args){
	myTh mt=new myTh();
}
}

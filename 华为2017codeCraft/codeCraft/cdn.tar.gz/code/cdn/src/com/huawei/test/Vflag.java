package com.huawei.test;
/**
 * 用于标识节点的类型
 * @author cristo
 *
 */
public class Vflag {
public static final int others=0;
public static final int constume=1;
public static final int server=2;
}
